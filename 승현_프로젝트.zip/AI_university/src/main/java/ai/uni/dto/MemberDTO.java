package ai.uni.dto;

public class MemberDTO {
	
	private String uni_id;
	private String uni_pw;

	public String getUni_id() {
		return uni_id;
	}
	public void setUni_id(String uni_id) {
		this.uni_id = uni_id;
	}
	public String getUni_pw() {
		return uni_pw;
	}
	public void setUni_pw(String uni_pw) {
		this.uni_pw = uni_pw;
	}

}
